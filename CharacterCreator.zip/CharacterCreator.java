import java.util.*;
abstract class Character {
    String name;
    Map<String, Object> appearance;
    List<Object> abilities;
    List<Object> equipment;
    Map<String, Object> attributes;

    public Character(String name) {
        this.name = name;
        this.appearance = new HashMap<>();
        this.abilities = new ArrayList<>();
        this.equipment = new ArrayList<>();
        this.attributes = new HashMap<>();
    }
}

//Конкретные продукты
class Warrior extends Character {
    public Warrior(String name) {
        super(name);
        // Add specific warrior abilities, equipment, and attributes
    }
}

class Mage extends Character {
    public Mage(String name) {
        super(name);
        // Add specific mage abilities, equipment, and attributes
    }
}

class Archer extends Character {
    public Archer(String name) {
        super(name);
        // Add specific archer abilities, equipment, and attributes
    }
}

//Абстрактная  фабрика
interface CharacterFactory {
    Character createCharacter(String name);
}

//Конкретные фабрики
class WarriorFactory implements CharacterFactory {
    public Character createCharacter(String name) {
        return new Warrior(name);
    }
}

class MageFactory implements CharacterFactory {
    public Character createCharacter(String name) {
        return new Mage(name);
    }
}

class ArcherFactory implements CharacterFactory {
    public Character createCharacter(String name) {
        return new Archer(name);
    }
}

//Клиентский код
public class CharacterCreator {
    private CharacterFactory factory;

    public CharacterCreator(CharacterFactory factory) {
        this.factory = factory;
    }

    public Character createCharacter(String name) {
        return factory.createCharacter(name);
    }

    public static void main(String[] args) {
        CharacterCreator creator = new CharacterCreator(new WarriorFactory());
        Character warrior = creator.createCharacter("Warrior 1");
        System.out.println(warrior.name);
    }
}
